import re
from collections import Counter


def clean_text(text):
    return re.sub(r'\s+', ' ', text)


def split_sentences(text):
    return re.split(r'(?<=[.!?]) +', text)


def word_freq(text):
    words = re.findall(r'\w+', text.lower())
    return Counter(words)


def generate_content(transcript):
    transcript = clean_text(transcript)

    sentences = split_sentences(transcript)
    freq = word_freq(transcript)

    scores = {}
    for sentence in sentences:
        words = re.findall(r'\w+', sentence.lower())
        scores[sentence] = sum(freq[word] for word in words)

    ranked = sorted(scores, key=scores.get, reverse=True)

    summary = " ".join(ranked[:5])
    key_points = ranked[:5]
    article = "\n".join(ranked[:10])

    return summary, key_points, article