import requests

def get_video_details(video_id):
    try:
        url = f"https://www.youtube.com/oembed?url=http://www.youtube.com/watch?v={video_id}&format=json"
        res = requests.get(url)
        data = res.json()

        return {
            "title": data["title"],
            "thumbnail": data["thumbnail_url"]
        }
    except:
        return {
            "title": "Unknown Title",
            "thumbnail": None
        }