from fpdf import FPDF


def clean_text(text):
    return text.encode('latin-1', 'ignore').decode('latin-1')


def create_pdf(title, summary, points, article):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    def write(text):
        pdf.multi_cell(0, 8, clean_text(text))

    write(f"Title: {title}\n\n")
    write(f"Summary:\n{summary}\n\n")

    write("Key Points:\n")
    for p in points:
        write(f"- {p}")

    write("\nArticle:\n")
    write(article)

    file_path = "article.pdf"
    pdf.output(file_path)

    return file_path