import streamlit as st
from utils.transcript import get_transcript, extract_video_id
from utils.generator import generate_content
from utils.pdf_generator import create_pdf
from utils.youtube_meta import get_video_details

st.set_page_config(page_title="YouTube Article Generator", layout="centered")

st.title("🎥 YouTube → Insightful Article Generator")

# Sample button
if st.button("Use Sample Video"):
    st.session_state.url = "https://www.youtube.com/watch?v=aircAruvnKk"

url = st.text_input("Enter YouTube URL", key="url")

if st.button("Generate Article"):

    if not url:
        st.warning("⚠️ Please enter a URL")

    else:
        with st.spinner("Fetching transcript..."):
            transcript, message = get_transcript(url)

        if not transcript:
            st.error(f"❌ {message}")

        else:
            video_id = extract_video_id(url)
            details = get_video_details(video_id)

            if details["thumbnail"]:
                st.image(details["thumbnail"])

            st.subheader(details["title"])

            with st.spinner("Generating content..."):
                summary, points, article = generate_content(transcript)

            st.subheader("🧾 Summary")
            st.write(summary)

            st.subheader("🔑 Key Points")
            for p in points:
                st.write(f"• {p}")

            st.subheader("📄 Article")
            st.write(article)

            with st.spinner("Creating PDF..."):
                pdf_path = create_pdf(details["title"], summary, points, article)

            with open(pdf_path, "rb") as f:
                st.download_button(
                    "📥 Download PDF",
                    f,
                    file_name="article.pdf",
                    mime="application/pdf"
                )