from youtube_transcript_api import YouTubeTranscriptApi

video_id = "aircAruvnKk"

try:
    data = YouTubeTranscriptApi.get_transcript(video_id)
    print("SUCCESS")
    print(data[:3])  # print first 3 lines
except Exception as e:
    print("ERROR:", e)